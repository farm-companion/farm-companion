import { NextRequest, NextResponse } from 'next/server';
import { workflowOrchestrator } from '../../../lib/workflow-orchestrator.js';
import { farmSelector } from '../../../lib/farm-selector.js';
import { contentGenerator } from '../../../lib/content-generator.js';
import { twitterClient } from '../../../lib/twitter-client.js';

/**
 * Vercel Cron Job: Daily Farm Spotlight
 * 
 * This endpoint is called by Vercel cron jobs to post daily farm spotlights
 * to Twitter/X at 09:05 Europe/London time.
 * 
 * Cron schedule: 5 8 * * * (daily at 08:05 UTC, which is 09:05 Europe/London)
 * 
 * Security: This endpoint should only be called by Vercel cron jobs
 * and requires the Vercel-Cron header for authentication.
 */
export async function GET(request) {
  return handleRequest(request, 'GET');
}

export async function POST(request) {
  return handleRequest(request, 'POST');
}

async function handleRequest(request, method) {
  const startTime = new Date();
  const workflowId = `cron-${startTime.toISOString().split('T')[0]}`;
  
  try {
    // Verify this is a legitimate Vercel cron request
    const cronSecret = request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;
    
    if (!expectedSecret || cronSecret !== `Bearer ${expectedSecret}`) {
      console.error('❌ Unauthorized cron request - missing or invalid CRON_SECRET');
      return NextResponse.json({ 
        error: 'Unauthorized',
        workflowId,
        timestamp: new Date().toISOString()
      }, { status: 401 });
    }

    // Check if we're in maintenance mode
    if (process.env.MAINTENANCE_MODE === 'true') {
      console.log('⚠️  Maintenance mode enabled, skipping daily spotlight');
      return NextResponse.json({ 
        success: true,
        message: 'Maintenance mode - workflow skipped',
        workflowId,
        timestamp: new Date().toISOString()
      });
    }

    console.log(`🕐 Starting daily farm spotlight workflow: ${workflowId}`);
    console.log(`📊 Method: ${method}`);
    console.log(`🌍 Timezone: ${process.env.TARGET_TIMEZONE || 'Europe/London'}`);
    console.log(`🔧 Environment: ${process.env.NODE_ENV || 'development'}`);
    
    // Pre-flight checks
    const preflightChecks = await performPreflightChecks();
    if (!preflightChecks.success) {
      console.error(`❌ Pre-flight checks failed: ${preflightChecks.error}`);
      return NextResponse.json({ 
        success: false,
        error: 'Pre-flight checks failed',
        details: preflightChecks.error,
        workflowId,
        timestamp: new Date().toISOString()
      }, { status: 500 });
    }
    
    // Execute the daily spotlight workflow
    const result = await workflowOrchestrator.executeDailySpotlight({
      workflowId,
      source: 'cron'
    });
    
    const endTime = new Date();
    const duration = endTime.getTime() - startTime.getTime();
    
    if (result.success) {
      console.log(`✅ Daily farm spotlight workflow completed successfully in ${Math.round(duration / 1000)}s`);
      
      // Log success metrics
      console.log(`📊 Success Metrics:`);
      console.log(`  Farm: ${result.steps.farmSelection?.farm?.name}`);
      console.log(`  Location: ${result.steps.farmSelection?.farm?.location?.county}`);
      console.log(`  Content Length: ${result.steps.contentGeneration?.content?.length} chars`);
      console.log(`  Tweet ID: ${result.steps.twitterPost?.tweetId}`);
      console.log(`  Duration: ${Math.round(duration / 1000)}s`);
      
      return NextResponse.json({ 
        success: true,
        message: 'Daily farm spotlight posted successfully',
        workflowId,
        timestamp: endTime.toISOString(),
        duration: duration,
        farm: result.steps.farmSelection?.farm?.name,
        location: result.steps.farmSelection?.farm?.location?.county,
        tweetId: result.steps.twitterPost?.tweetId,
        content: result.steps.contentGeneration?.content?.substring(0, 100) + '...',
        metrics: {
          farmIndex: result.steps.farmSelection?.farmIndex,
          totalFarms: result.steps.farmSelection?.totalFarms,
          contentLength: result.steps.contentGeneration?.content?.length,
          executionTime: Math.round(duration / 1000)
        }
      });
    } else {
      console.error(`❌ Daily farm spotlight workflow failed: ${result.error}`);
      
      // Log failure details
      console.error(`📊 Failure Details:`);
      console.error(`  Error: ${result.error}`);
      console.error(`  Steps: ${Object.keys(result.steps || {}).join(', ')}`);
      
      return NextResponse.json({ 
        success: false,
        error: result.error,
        workflowId,
        timestamp: endTime.toISOString(),
        duration: duration,
        steps: result.steps
      }, { status: 500 });
    }

  } catch (error) {
    const endTime = new Date();
    const duration = endTime.getTime() - startTime.getTime();
    
    console.error(`❌ Fatal error in daily farm spotlight workflow: ${error.message}`);
    console.error('Stack trace:', error.stack);
    
    return NextResponse.json({ 
      success: false,
      error: 'Internal server error',
      details: error.message,
      workflowId,
      timestamp: endTime.toISOString(),
      duration: duration
    }, { status: 500 });
  }
}

/**
 * Perform pre-flight checks before executing the workflow
 */
async function performPreflightChecks() {
  try {
    console.log('🔍 Performing pre-flight checks...');
    
    // Check if farm data is accessible
    const farmStats = await farmSelector.getSelectionStats();
    if (!farmStats.success) {
      return { success: false, error: `Farm data not accessible: ${farmStats.error}` };
    }
    
    if (farmStats.stats.totalFarms < 10) {
      return { success: false, error: 'Insufficient farm data available' };
    }
    
    // Check if content generation is working
    const contentTest = await contentGenerator.testGeneration();
    if (!contentTest.success && !contentTest.apiKeyConfigured) {
      console.log('⚠️  DeepSeek API not configured, will use fallback content');
    }
    
    // Check if Twitter client can be initialized (if API keys are provided)
    if (process.env.TWITTER_API_KEY) {
      const twitterTest = await twitterClient.testConnection();
      if (!twitterTest.success) {
        console.log('⚠️  Twitter API not accessible, will run in dry run mode');
      }
    } else {
      console.log('⚠️  Twitter API keys not configured, will run in dry run mode');
    }
    
    console.log('✅ Pre-flight checks passed');
    return { success: true };
    
  } catch (error) {
    return { success: false, error: error.message };
  }
}
